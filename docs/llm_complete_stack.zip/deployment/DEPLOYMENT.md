# Deployment
Stack:
- FastAPI
- Router
- vLLM
- GPU/CPU hybrid
