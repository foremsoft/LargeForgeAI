# Inference
vllm serve Qwen/Qwen2.5-7B --quantization awq
