# Distillation stub
# Teacher outputs are used as targets for student model
