# Low-Cost LLM Whitepaper

This document explains how startups can build GPT-4-level systems under $10k using modern techniques.
