## Costs
Total estimated cost: $8k–$12k
