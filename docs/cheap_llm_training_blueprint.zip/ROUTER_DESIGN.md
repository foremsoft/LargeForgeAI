## Router Design
Lightweight classifier routes requests to experts
