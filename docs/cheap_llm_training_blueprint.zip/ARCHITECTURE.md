## Architecture
Base model → Synthetic data → Distillation → Preference tuning → Experts → Router → Deployment
