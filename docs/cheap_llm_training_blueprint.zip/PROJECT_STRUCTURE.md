## Project Structure
llm/
 data/
 training/
 experts/
 router/
 inference/
 docs/
